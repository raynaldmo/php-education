<?php
printf( "%02d/%02d/%d", 3, 24, 2008 ); // Displays "03/24/2008"
?>
