<?php
require_once( "../common.inc.php" );
checkLogin();
displayPageHeader( "Contact the book club", true );
?>

<p>You can contact Marian, the organizer of the book club, on <strong>187-812-8166</strong>.</p>

<p><a href="index.php">Members' area home page</a></p>

<?php displayPageFooter(); ?>
