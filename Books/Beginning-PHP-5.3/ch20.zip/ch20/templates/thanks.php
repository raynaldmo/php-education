<?php include "page_header.php" ?>

    <h1>Thank You</h1>
    <p>Thank you, your application has been received.</p>

<?php include "page_footer.php" ?>
