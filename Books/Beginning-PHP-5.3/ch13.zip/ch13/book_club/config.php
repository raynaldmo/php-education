<?php
define( "DB_DSN", "mysql:dbname=mydatabase" );
define( "DB_USERNAME", "root" );
define( "DB_PASSWORD", "mypass" );
define( "PAGE_SIZE", 5 );
define( "TBL_MEMBERS", "members" );
define( "TBL_ACCESS_LOG", "accessLog" );
?>
