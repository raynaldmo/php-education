<?php
echo "Hello, world!";
?>

