<?php
define('BASEDIR', '/srv/apache/wrox/ch_07/albums');

define('FILETYPE_DIRECTORY', 1);
define('FILETYPE_FILE', 2);
?>
