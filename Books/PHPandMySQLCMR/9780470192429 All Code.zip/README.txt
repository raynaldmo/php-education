**********************************************************************
            Thank you for downloading the source code for
                "PHP & MYSQL: CREATE, MODIFY, REUSE."
**********************************************************************

The source code for the following chapters are included:

Chapter 1  - Contains the source code for the User Registration
             project.

Chapter 2  - Contains the source code for the Community Forum
             project.

Chapter 3  - Contains the source code for the Mailing List project.

Chapter 4  - Contains the source code for the Search Engine project.

Chapter 5  - Contains the source code for the Personal Calender
             project.

Chapter 6  - Contains the source code for the AJAX File Manager
             project.

Chapter 7  - Contains the source code for the Online Photo Album
             
Chapter 8  - Contains the source code for the Shopping Cart project.

Chapter 9  - Contains the source code for the Website Statistics
             project.

Chapter 10 - Contains the source code for the News/Blog project.

Chapter 11 - Contains the source code for the Shell Script project.

Chapter 12 - Contains the source code listings for Chapter 12.

**********************************************************************
Please use the Errata form for the book on www.wrox.com to send
comments, bug reports, etc.
**********************************************************************
