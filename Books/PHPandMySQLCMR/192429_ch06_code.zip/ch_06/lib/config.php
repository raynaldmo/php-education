<?php
define('BASEDIR', '/srv/apache/wrox/ch_06/files');
?>
