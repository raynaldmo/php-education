<!DOCTYPE html>
<html lang="en">
<head>
<meta charset=utf-8>
<title>Contest Entry</title>
</head> 
<body> 
<div style='z-index:2; position:absolute; top:0; left:0;
  width:70%; height:70%'> 
<iframe src='http://localhost/EPMADD/06-PHP/account.php'
style='opacity:0' width=100% height=100%
onmouseover="this.style.opacity = .5;""
onmouseout="this.style.opacity = 0;"
> 
</iframe> 
</div> 
<div style='z-index:1; position:absolute; top:0; left:0;
  width:70%; height:70%; background-color:yellow;'> 
<div style='margin-left: 10px;'>
<p style='font-size:30px; font-style:italic;'>
Movie Contest Promotion
<p style='font-size: 18px;'>
To enter the contest and receive
<br>
two free movie tickets, click the
<br>
button below.
<br>
(We already have your email.)
<p style='position:absolute; top:272px; left:20px;'>
<button>Enter Contest</button>
</div>
</div>
</body> 
</html>