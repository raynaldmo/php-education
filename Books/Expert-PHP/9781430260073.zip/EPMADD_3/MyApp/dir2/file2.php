<p>dir2, file2
