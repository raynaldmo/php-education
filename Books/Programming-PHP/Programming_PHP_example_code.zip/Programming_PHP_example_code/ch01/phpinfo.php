<?php phpinfo() ; ?>
