<?php
namespace Foo;

class Bar
{
    public function sayHello()
    {
        echo "Hi there";
    }
}
