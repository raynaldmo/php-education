role :web, %w{deploy@123.456.78.90}
