window.kfm_closeContextMenu=function(){
	$j('.contextmenu').remove();
}
