window.kfm_leftColumn_enable=function(){
	var hider=document.getElementById("kfm_left_column_hider");
	if(!hider)return;
	hider.parentNode.removeChild(hider);
	kfm_resizeHandler_removeMaxHeight('kfm_left_column_hider');
}
