window.kfm_resizeHandler_remove=function(name){
	kfm_resizeHandler_removeMaxWidth(name);
	kfm_resizeHandler_removeMaxHeight(name);
}
