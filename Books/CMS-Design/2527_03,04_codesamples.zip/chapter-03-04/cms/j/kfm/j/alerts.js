// see license.txt for licensing
llStubs.push('kfm_showMessage');
