window.kfm_resizeHandler_removeMaxHeight=function(name){
	if(kfm_resizeHandler_maxHeights.indexOf(name)!=-1)kfm_resizeHandler_maxHeights=array_remove_values(kfm_resizeHandler_maxHeights,name);
}
