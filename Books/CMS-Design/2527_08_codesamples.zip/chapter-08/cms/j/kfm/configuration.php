<?php
$kfm_userfiles_address=$_SERVER['DOCUMENT_ROOT'].'/f/';
$kfm_userfiles_output='/f/';
$kfm_dont_send_metrics=1;
