<?php
$DBVARS=array(
	'username'=>'cmsuser',
	'password'=>'cmspass',
	'hostname'=>'localhost',
	'db_name'=>'cmsdb'
);
