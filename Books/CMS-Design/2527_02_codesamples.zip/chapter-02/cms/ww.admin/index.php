<?php
require 'header.php';
echo 'you are logged in!';
require 'footer.php';
