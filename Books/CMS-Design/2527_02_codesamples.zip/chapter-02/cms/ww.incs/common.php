<?php
require dirname(__FILE__).'/basics.php';
