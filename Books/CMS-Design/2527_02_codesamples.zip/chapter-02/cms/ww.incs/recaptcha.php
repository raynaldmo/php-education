<?php
require SCRIPTBASE.'ww.incs/recaptcha-php-1.10/recaptchalib.php';

define('RECAPTCHA_PRIVATE','6LffZAwAAAAAANXRgBLgD51o6fZnvXknLNNXgCUr');
define('RECAPTCHA_PUBLIC','6LffZAwAAAAAALA70eSDf73p4DTddBu0jgULjukb');
