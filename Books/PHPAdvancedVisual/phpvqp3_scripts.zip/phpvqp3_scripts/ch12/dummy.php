#!/usr/bin/php
<?php
// Do whatever.
?>
This text is also displayed.
<?php
// Do whatever.
?>