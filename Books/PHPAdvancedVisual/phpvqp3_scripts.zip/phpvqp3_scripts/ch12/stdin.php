#!/usr/bin/php
<?php
echo 'Tell me something: ';
$input = fgets(STDIN);
?>
