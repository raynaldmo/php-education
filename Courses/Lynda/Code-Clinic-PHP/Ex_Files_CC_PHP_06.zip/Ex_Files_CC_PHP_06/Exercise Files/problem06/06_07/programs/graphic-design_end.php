<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Graphic Design Programs</title>
<!--[if lt IE 9]>
<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<!--[if lt IE 9]>
<script src="../_scripts/respond.min.js"></script>
<![endif]-->
<link href="../_css/main.css" rel="stylesheet" media="screen, projection">
</head>
<body>
<header class="graphicHeader pageHeader">
<h1>Roux Academy of Art and Design<a href="/index.htm" title="home"></a></h1>
<nav id="pageNav" class="cf">
  <ul>
    <li><a href="../programs.htm" title="programs">Programs</a></li>
    <li><a href="../admissions.htm" title="admissions">Admissions</a></li>
    <li><a href="../student_portal.htm" title="student portal">Student Portal</a></li>
    <li><a href="../campus_portal.htm" title="campus portal">Campus</a></li>
    <li><a href="../alumni.htm" title="alumni">Alumni</a></li>
    <li><a href="../about/about.htm"  title="about Roux Academy">About</a></li>
  </ul>
</nav>
</header>
<article id="mainContent">
  <h1>Graphic Design</h1>
  <p>The Graphic Design program helps students to develop skills in listening, negotiating, research, thinking creatively, idea generation, and manipulating visual languages and techniques. Students are encouraged to cultivate and share ideas, as well as develop their own philosophy and unique way of working. </p>
  <blockquote>Roux Academy's Graphic Desgin program helped me mature both as a designer and as a creative professional. Their cross-disciplinary approach helped me see multiple sides and solutions to every problem I encountered, and that's something that has translated to how I approach design in my career. Roux Academy was tremendously important in helping shape the designer I've become. <span class="quote">&#8211;Tabitha Knowles, Lead Designer Veroscare Partners</span></blockquote>
  <h2>Required Curriculum</h2>
  <p>While every program is different and course loads are tailored to meet the individual student&rsquo;s needs, this list represents the required curriculum for any student seeking a BA in Graphic Design.</p>
    <?php
    ini_set('auto_detect_line_endings', '1');
    require_once '../includes/csv_functions.php';
    if ($table1 = extractCsv('../_assets/first_semester.csv')) { ?>
        <table>
            <tr>
                <th>First Semester</th>
                <th>Credit Hours</th>
            </tr>
            <?php foreach ($table1 as $row) { ?>
            <tr>
                <td>
                    <?php
                    $space = strpos($row['First Semester'], ' ');
                    echo '<strong>' . substr_replace($row['First Semester'],
                        '</strong>', $space, 0);
                    ?>
                </td>
                <td>
                    <?php echo $row['credit hours']; ?>
                </td>
            </tr>
            <?php } ?>
        </table>
    <?php } else {
        echo '<p><em>Curriculum for semester 1 not available.</em></p>';
    }
    if ($table2 = extractCsv('../_assets/second_semester.csv')) { ?>
        <table>
            <tr>
                <th>Second Semester</th>
                <th>Credit Hours</th>
            </tr>
            <?php foreach ($table2 as $row) { ?>
                <tr>
                    <td>
                        <?php
                        $space = strpos($row['Second Semester'], ' ');
                        echo '<strong>' . substr_replace($row['Second Semester'],
                                '</strong>', $space, 0);
                        ?>
                    </td>
                    <td>
                        <?php echo $row['credit hours']; ?>
                    </td>
                </tr>
            <?php } ?>
        </table>
    <?php } else {
        echo '<p><em>Curriculum for semester 2 not available.</em></p>';
    }
    ?>
</article>
<aside>
<section class="academic info">
<h2>Academic Links</h2>
<ul>
  <li><a href="undergraduate.htm" title="undergraduate degrees">Undergraduate Degrees</a></li>
  <li><a href="graduate.htm" title="Graduate Degrees">Graduate Degree Programs</a></li>
  <li><a href="continuing-education.htm" title="Continuing education">Continuing Education</a></li>
  <li><a href="faculty.htm" title="Faculty">Faculty Profiles</a></li>
   <li><a href="application-requirement.htm" title="Application requirements">Application Requirements</a></li>
  <li><a href="study-abroad.htm" title="Study abroad programs">Study Abroad Programs</a></li>
  <li><a href="internships.htm" title="Internship programs">Internship Programs</a></li>
  <li><a href="calendar.htm" title="Academic calendar">Academic Calendar</a></li>
</ul>
</section>
<section class="connect info">
<h2>Connect with us</h2>
<ul>
  <li><a href="http://www.twitter.com/rouxacademy" title="Follow us!" target="_blank" class="twitter">Twitter</a></li>
  <li><a href="https://plus.google.com/" title="Google Plus" target="_blank" class="google">Google Plus</a></li>
  <li><a href="http://facebook.com" title="Be our friend" target="_blank" class="facebook">Facebook</a></li>
  <li><a href="http://www.linkedin.com" title="Let's connect" target="_blank" class="linked">LinkedIn</a></li>
</ul>
</section>
<section class="find info">
<h2>Find out more</h2>
<ul>
<li><a href="../tour.htm" title="Take a campus tour">Take a campus tour</a></li>
<li><a href="../catalog.htm" title="course catalog">Download a course catalog</a></li>
<li><a href="../admissions.htm" title="Apply now">Apply now</a></li>
</ul>
</section>
<section class="show info">
<h2>Current Show</h2>
<img src="../_images/show1.jpg" width="285" height="230" alt="Current show">
<p>Join us on May 11th for the opening reception of Ceramic Currency, an annual show presented by graduates from the Craft and Design program. Come see an exhibition of contemporary pottery and ceramic sculpture by over 30 artists. <a href="current_show.htm" title="current show" class="more">more info</a></p>
</section>
</aside>
<footer id="pageFooter" class="cf">
<nav class="footerNav">
<section class="col">
<h3>About Roux Academy</h3>
  <div class="col1">
  <ul>
  <li><a href="../mission.htm" title="Our mission">Mission Statement</a></li>
  <li><a href="../history.htm" title="school history">School History</a></li>
  <li><a href="../accreditation.htm" title="accreditation and affliates">Accreditation &amp; Affiliates</a></li>
  <li><a href="../board.htm" title="board members">Board Members</a></li>
  </ul>
  </div>
  <div class="col2">
  <ul>
  <li><a href="../faculty.htm" title="faculty and staff">Faculty &amp; Staff</a></li>
  <li><a href="../visiting_professors.htm" title="visiting professors">Visiting Professors</a></li>
  <li><a href="../museum.htm" title="Maribielle Roux Museum">Marbielle Roux Museum</a></li>
  <li><a href="../directions.htm" title="directions">Map &amp; Directions</a></li>
  </ul>
  </div>
</section>
<section class="col">
<h3>Admissions &amp; Programs</h3>
  <div class="col1">
  <ul>
  <li><a href="../degrees.htm" title="Degree programs">Degree Programs</a></li>
  <li><a href="../catalog.htm" title="course catalog">Course Catalog</a></li>
  <li><a href="../fine_art.htm" title="fine art programs">Fine Art Programs</a></li>
  <li><a href="../design.htm" title="design concentration">Design Concentration</a></li>
  </ul>
  </div>
  <div class="col2">
  <ul>
  <li><a href="../fashion.htm" title="fashion program">Fashion Program</a></li>
  <li><a href="../product_design.htm" title="product design">Product Design</a></li>
  <li><a href="../continuing_ed.htm" title="Continuing Education">Continuing Education</a></li>
  <li><a href="../financial_aid.htm" title="tuition and financial aid">Tuition &amp; Financial Aid</a></li>
  </ul>
  </div>
</section>
<section class="col">
<h3>Student Resources</h3>
  <div class="col1">
  <ul>
  <li><a href="../campus.htm" title="Campus information">Campus Information</a></li>
  <li><a href="../housing.htm" title="student housing">Student Housing</a></li>
  <li><a href="../contact.htm" title="transcript request">Transcript Request</a></li>
  <li><a href="../applying.htm" title="application process">Application Process</a></li>
  </ul>
  </div>
  <div class="col2">
  <ul>
  <li><a href="../portfolio_review.htm" title="portfolio review">Portfolio Review</a></li>
  <li><a href="../conselling.htm" title="career counselling">Career Counselling</a></li>
  <li><a href="../internships.htm" title="internship programs">Internship Programs</a></li>
  <li><a href="../student_portal.htm" title="student portal login">Student Portal Login</a></li>
   </ul>
  </div>
</section>
</nav>
<p>&copy;Copyright  Roux Academy of Art &amp; Design.  All rights reserved.<a href="../privacy.htm" title="privacy statement"> Privacy Statement</a> |<a href="../legal.htm" title="legal terms"> Legal Terms and Conditions</a> |<a href="../disclosures.htm" title="student outcomes and disclosures"> Student Outcomes/Disclosures</a></p>
</footer>
</body>
</html>
