<?php

echo "This line is fine.";

echo "This line will generate a parse error."