<!DOCTYPE HTML>
<html>
<head>
	<title>Baseball Stats</title>
    <link rel="stylesheet" type="text/css" href="./includes/css/main.css" >
        <link rel="stylesheet" type="text/css" href="./includes/css/layout.css" >

        <link rel="stylesheet" type="text/css" href="./includes/css/skeleton.css" >

<head>
	
<body>
	<div class="container">
		<h1>Baseball Stats</h1>
		<h3><a href="create.php">Add Player</a></h3><hr />
