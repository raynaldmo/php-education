<?
//if BaseballApi Class were inaccessible, we'd need to mock the object. 
class BaseballApi
{
    public function submitAtBat($playerid,$result)
    {
    	//insert into database
        return true;
    }
}
 
?>