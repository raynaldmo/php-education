<?php
namespace stats\Test;

use stats\BaseballApi;

class BaseballApiTest extends \PHPUnit_Framework_TestCase
{
    public function test_MockObject()
    {
       

    }
}

?>