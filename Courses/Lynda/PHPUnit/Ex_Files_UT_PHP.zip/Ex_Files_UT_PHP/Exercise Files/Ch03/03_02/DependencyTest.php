<?php
namespace stats\Test;

use stats\Baseball;

class BaseballTest extends \PHPUnit_Framework_TestCase
{
   
//because OPS is sum total of on base percentage plus sluggin average, we can use the depends annotation 
 



  



 }  