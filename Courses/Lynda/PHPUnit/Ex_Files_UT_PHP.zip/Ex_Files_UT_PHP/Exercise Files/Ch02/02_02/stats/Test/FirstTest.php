<?php
class FirstTest extends \PHPUnit_Framework_TestCase
{
	public function testUselessness()
	{
		$this->assertTrue(true);
	}
    //
}