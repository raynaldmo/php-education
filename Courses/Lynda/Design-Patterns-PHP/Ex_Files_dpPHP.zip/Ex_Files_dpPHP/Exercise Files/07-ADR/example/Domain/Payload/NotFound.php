<?php
namespace Domain\Payload;

class NotFound extends AbstractPayload
{
}
