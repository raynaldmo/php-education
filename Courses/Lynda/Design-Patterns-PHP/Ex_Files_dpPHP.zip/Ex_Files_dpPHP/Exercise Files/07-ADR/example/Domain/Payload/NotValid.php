<?php
namespace Domain\Payload;

class NotValid extends AbstractPayload
{
}
