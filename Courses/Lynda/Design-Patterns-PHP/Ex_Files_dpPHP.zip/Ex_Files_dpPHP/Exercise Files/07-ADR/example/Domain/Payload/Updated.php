<?php
namespace Domain\Payload;

class Updated extends AbstractPayload
{
}
