<?php
namespace Domain\Payload;

class Deleted extends AbstractPayload
{
}
