<?php
namespace Domain\Payload;

class NotDeleted extends AbstractPayload
{
}
