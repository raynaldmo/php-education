<?php
namespace Domain\Payload;

class Created extends AbstractPayload
{
}
