<?php
namespace Domain\Payload;

class Valid extends AbstractPayload
{
}
