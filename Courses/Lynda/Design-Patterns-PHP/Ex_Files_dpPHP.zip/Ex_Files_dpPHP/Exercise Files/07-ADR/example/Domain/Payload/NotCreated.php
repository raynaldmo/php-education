<?php
namespace Domain\Payload;

class NotCreated extends AbstractPayload
{
}
