<?php
namespace Domain\Payload;

class NewEntity extends AbstractPayload
{
}
