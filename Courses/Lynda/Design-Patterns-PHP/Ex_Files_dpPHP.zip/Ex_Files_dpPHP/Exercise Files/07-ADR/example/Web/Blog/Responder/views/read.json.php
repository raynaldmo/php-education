<?php
echo json_encode($this->blog);
