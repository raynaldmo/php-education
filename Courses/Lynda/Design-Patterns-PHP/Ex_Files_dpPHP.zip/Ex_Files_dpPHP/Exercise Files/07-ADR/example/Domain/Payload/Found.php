<?php
namespace Domain\Payload;

class Found extends AbstractPayload
{
}
