<?php
namespace Domain\Payload;

class NotUpdated extends AbstractPayload
{
}
