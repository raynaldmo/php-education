<?php
namespace Domain\Payload;

class Error extends AbstractPayload
{
}
